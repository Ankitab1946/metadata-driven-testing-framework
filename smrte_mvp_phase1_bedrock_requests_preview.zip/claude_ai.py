import os
import json
import boto3

aws_access_key_id = os.getenv("AWS_ACCESS_KEY_ID")
aws_secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY")
aws_session_token = os.getenv("AWS_SESSION_TOKEN")
aws_region = os.getenv("AWS_REGION", "us-east-1")

MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-5-sonnet-20240620-v1:0")

# initialize bedrock client
if aws_session_token:
    bedrock = boto3.client(
        "bedrock-runtime",
        region_name=aws_region,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        aws_session_token=aws_session_token
    )
else:
    bedrock = boto3.client(
        "bedrock-runtime",
        region_name=aws_region,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key
    )

def _extract_text_from_response(obj):
    """Recursively find the first string value that looks like model text in the Bedrock response."""
    if isinstance(obj, dict):
        # common keys: 'content' -> list -> dict with 'text'
        if 'text' in obj and isinstance(obj['text'], str):
            return obj['text']
        for v in obj.values():
            t = _extract_text_from_response(v)
            if t:
                return t
    elif isinstance(obj, list):
        for item in obj:
            t = _extract_text_from_response(item)
            if t:
                return t
    elif isinstance(obj, str):
        return obj
    return None

def _invoke_bedrock_system(prompt: str, max_tokens: int = 1000):
    body = {
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens
    }
    response = bedrock.invoke_model(
        modelId=MODEL_ID,
        contentType="application/json",
        accept="application/json",
        body=json.dumps(body)
    )
    resp_body = json.loads(response['body'].read())
    text = _extract_text_from_response(resp_body) or json.dumps(resp_body)
    return text

def _extract_json_array(text: str):
    """Try to extract a JSON array substring from text (from first '[' to last ']')."""
    try:
        start = text.index('[')
        end = text.rindex(']') + 1
        candidate = text[start:end]
        return json.loads(candidate)
    except Exception:
        raise

def generate_stories_json(epic_description: str, num_stories: int = 5):
    prompt = f"""Break down this Epic into {num_stories} user stories.
Respond ONLY in JSON array format like:
[
  {{
    "title": "..." ,
    "description": "..." ,
    "acceptance_criteria": "..."
  }}
]

Epic: {epic_description}
"""
    text = _invoke_bedrock_system(prompt, max_tokens=1500)
    # Try direct parse, else try to extract JSON array substring
    try:
        parsed = json.loads(text)
        if isinstance(parsed, list):
            return parsed
    except Exception:
        try:
            arr = _extract_json_array(text)
            if isinstance(arr, list):
                return arr
        except Exception:
            return {"error": "failed_to_parse_json", "raw": text}
    return {"error": "unexpected_response", "raw": text}

def agile_qabot(question: str):
    prompt = f"You are an experienced Agile/SAFe expert. Answer clearly and concisely:\n\n{question}"
    text = _invoke_bedrock_system(prompt, max_tokens=800)
    return text
