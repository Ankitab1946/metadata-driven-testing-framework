# SM + RTE AI Workspace — Phase-1 (Preview before Create)

## What this contains
- Streamlit app that generates user stories from an Epic using an LLM via AWS Bedrock.
- Allows previewing generated stories and selecting which ones to create in Jira.
- Dependency visualization using Jira issuelinks.
- Agile Q&A powered by the model.

## Setup
1. Copy `.env.example` to `.env` and fill in your AWS and Jira credentials.
2. (Optional) update `BEDROCK_MODEL_ID` in `.env` if you want a different model.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run locally:
   ```bash
   streamlit run streamlit_app.py
   ```

## Docker
   ```bash
   docker build -t smrte-mvp .
   docker run -p 8501:8501 --env-file .env smrte-mvp
   ```

## Notes
- Verify `JIRA_EPIC_LINK_FIELD` if you want the created stories linked to an Epic. Jira Cloud commonly uses `customfield_10014`, but your instance may differ.
- Bedrock/API responses can vary; the app attempts to parse JSON arrays from the model output. If parsing fails, you'll see raw output for debugging.
