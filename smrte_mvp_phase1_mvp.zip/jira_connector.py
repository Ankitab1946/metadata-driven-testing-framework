import os
from atlassian import Jira

class JiraConnector:
    def __init__(self):
        self.jira = Jira(
            url=os.getenv("JIRA_URL"),
            username=os.getenv("JIRA_USER"),
            password=os.getenv("JIRA_TOKEN")
        )

    def get_epics(self, project_key):
        return self.jira.jql(f'project={project_key} AND issuetype=Epic')

    def get_stories_with_dependencies(self, project_key):
        issues = self.jira.jql(f'project={project_key} AND issuetype=Story')
        results = []
        for issue in issues.get("issues", []):
            results.append({
                "id": issue.get("key"),
                "summary": issue.get("fields", {}).get("summary"),
                # adjust customfield_XXXXX to your dependency field id if you have one
                "dependencies": issue.get("fields", {}).get("customfield_XXXXX", [])
            })
        return results

    def create_story(self, project_key, summary, description, epic_key=None):
        issue_data = {
            "fields": {
                "project": {"key": project_key},
                "summary": summary,
                "description": description,
                "issuetype": {"name": "Story"}
            }
        }
        # attach to Epic if provided:
        if epic_key:
            # adjust customfield_10014 to your Epic Link field id
            issue_data["fields"]["customfield_10014"] = epic_key

        new_issue = self.jira.issue_create(issue_data)
        return new_issue
