# SM+RTE AI Ecosystem — Phase-1 MVP (Streamlit)

## What this package contains
A minimal Phase-1 MVP that:
- Accepts an Epic description and uses Claude (Anthropic) to generate JSON user stories.
- Allows pushing generated stories into Jira (linked to an Epic).
- Visualizes story dependencies fetched from Jira.
- Provides an Agile Q&A chatbot powered by Claude.

## Setup
1. Copy `.env.example` to `.env` and fill your keys.
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   streamlit run streamlit_app.py
   ```

## Notes
- Check your Jira custom field IDs (Epic Link is commonly `customfield_10014` in Cloud). Update `jira_connector.py` if needed.
- This package does NOT include keys or secrets. Add them to `.env`.
