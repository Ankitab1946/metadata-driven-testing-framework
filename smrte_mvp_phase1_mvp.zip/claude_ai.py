import os
import json
from anthropic import Anthropic

client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

def generate_stories_json(epic_description: str, num_stories: int = 5):
    prompt = f"""
    Break down this Epic into {num_stories} user stories.
    Respond ONLY in JSON array format like:
    [
      {
        "title": "...",
        "description": "...",
        "acceptance_criteria": "..."
      }
    ]

    Epic: {epic_description}
    """
    response = client.messages.create(
        model="claude-3-5-sonnet-20240620",
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}]
    )
    # Anthropic SDK returns a structure with 'content' containing text
    text = response.content[0].text if hasattr(response, 'content') else str(response)
    try:
        return json.loads(text)
    except Exception as e:
        # Fallback: return empty list and include raw text for debugging
        return {"error": str(e), "raw": text}

def agile_qabot(question: str):
    prompt = f"You are an Agile/SAFe expert. Answer clearly:\n\n{question}"
    response = client.messages.create(
        model="claude-3-5-sonnet-20240620",
        max_tokens=800,
        messages=[{"role": "user", "content": prompt}]
    )
    text = response.content[0].text if hasattr(response, 'content') else str(response)
    return text
