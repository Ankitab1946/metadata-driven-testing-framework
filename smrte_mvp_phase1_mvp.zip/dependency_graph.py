import networkx as nx
import matplotlib.pyplot as plt
import streamlit as st

def plot_dependency_graph(stories):
    G = nx.DiGraph()
    for s in stories:
        node_id = s.get("id") or s.get("title") or "unknown"
        G.add_node(node_id, label=s.get("summary") or s.get("title") or node_id)
        for dep in s.get("dependencies", []):
            if dep:
                G.add_edge(node_id, dep)

    fig, ax = plt.subplots(figsize=(8, 6))
    if len(G.nodes) == 0:
        st.info("No nodes to display in dependency graph.")
        return
    pos = nx.spring_layout(G)
    nx.draw_networkx_nodes(G, pos, node_size=900, ax=ax)
    nx.draw_networkx_labels(G, pos, labels={n: n for n in G.nodes()}, ax=ax, font_size=9)
    nx.draw_networkx_edges(G, pos, arrowstyle='-|>', arrowsize=12, ax=ax)
    st.pyplot(fig)
