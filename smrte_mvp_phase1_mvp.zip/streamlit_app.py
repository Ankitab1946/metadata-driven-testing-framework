import streamlit as st
from dotenv import load_dotenv
from jira_connector import JiraConnector
from claude_ai import generate_stories_json, agile_qabot
from dependency_graph import plot_dependency_graph
import os

load_dotenv()
jc = JiraConnector()

st.set_page_config(page_title="SM + RTE AI Assistant", layout="wide")
st.title("🤝 SM + RTE AI Ecosystem – Phase-1 MVP")

tab1, tab2, tab3 = st.tabs(["Epic → Stories", "Dependency Graph", "Agile Q&A"])

with tab1:
    st.subheader("Break Epic into Stories & Push to Jira")
    project = st.text_input("Jira Project Key (e.g. ABC):")
    epic_key = st.text_input("Epic Key (optional, e.g. ABC-123):")
    epic_text = st.text_area("Enter Epic Description:")
    num = st.slider("Number of stories", 1, 10, 5)

    if st.button("Generate Stories"):
        if epic_text.strip():
            result = generate_stories_json(epic_text, num)
            if isinstance(result, dict) and result.get('error'):
                st.error("Failed to parse Claude response as JSON. See raw output below for debugging.")
                st.code(result.get('raw', ''))
            else:
                stories = result
                st.session_state["stories"] = stories
                st.markdown("### AI Suggested Stories")
                for i, s in enumerate(stories, start=1):
                    st.write(f"**Story {i}:** {s.get('title')}")
                    st.write(s.get('description'))
                    st.write(f"*Acceptance Criteria:* {s.get('acceptance_criteria')}")
                st.success("Stories generated. Review above.")

    if "stories" in st.session_state and st.button("Create Stories in Jira"):
        if project.strip():
            results = []
            for s in st.session_state["stories"]:
                desc = f"{s.get('description')}\n\nAcceptance Criteria:\n{s.get('acceptance_criteria')}"
                new_issue = jc.create_story(project, s.get('title'), desc, epic_key or None)
                # atlassian-python-api returns an object / dict depending on config; try to read key
                new_key = None
                if isinstance(new_issue, dict):
                    new_key = new_issue.get('key') or new_issue.get('id')
                else:
                    # some libs return an object with key attribute
                    new_key = getattr(new_issue, 'key', str(new_issue))
                results.append(str(new_key))
            st.success(f"Created {len(results)} stories in Jira: {', '.join(results)}")

with tab2:
    st.subheader("Visualize Dependencies from Jira")
    project_dep = st.text_input("Jira Project Key for Dependencies (e.g. ABC):", key="dep_proj")
    if st.button("Fetch Dependencies"):
        if project_dep.strip():
            stories_dep = jc.get_stories_with_dependencies(project_dep)
            st.write("Fetched", len(stories_dep), "stories")
            plot_dependency_graph(stories_dep)

with tab3:
    st.subheader("Agile Knowledge Hub (Claude Q&A)")
    question = st.text_input("Ask a SAFe/Agile question:")
    if st.button("Get Answer"):
        if question.strip():
            answer = agile_qabot(question)
            st.markdown("### Answer")
            st.write(answer)
