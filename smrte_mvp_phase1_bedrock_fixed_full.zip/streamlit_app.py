import streamlit as st
from claude_ai import split_feature_to_stories
from jira_connector import create_jira_story
import pandas as pd

st.title("SM+RTE AI Workspace")

feature = st.text_area("Paste Feature/Epic description")
if st.button("Generate Stories"):
    stories = split_feature_to_stories(feature)
    st.session_state["stories"] = stories

if "stories" in st.session_state:
    df = pd.DataFrame(st.session_state["stories"])
    st.dataframe(df)
    selected = st.multiselect("Select stories to create", df.index)
    if st.button("Create selected stories in Jira"):
        for i in selected:
            story = st.session_state["stories"][i]
            create_jira_story(story["title"], story.get("description",""))
        st.success("Stories created in Jira")