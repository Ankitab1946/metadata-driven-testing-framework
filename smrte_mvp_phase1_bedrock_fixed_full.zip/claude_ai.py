import os, json, boto3

bedrock = boto3.client(
    "bedrock-runtime",
    region_name=os.getenv("AWS_REGION", "us-east-1"),
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    aws_session_token=os.getenv("AWS_SESSION_TOKEN"),
)

def split_feature_to_stories(feature_text: str):
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 800,
        "messages": [
            {"role": "user",
             "content": [{"type": "text", "text": f"Split this feature into user stories with details:\n\n{feature_text}"}]}
        ]
    }
    resp = bedrock.invoke_model(
        modelId=os.getenv("BEDROCK_MODEL_ID"),
        contentType="application/json",
        accept="application/json",
        body=json.dumps(body)
    )
    data = json.loads(resp["body"].read())
    try:
        text = data["content"][0]["text"]
        stories = json.loads(text)
    except Exception:
        stories = [{"title":"Story1","description":data}]
    return stories