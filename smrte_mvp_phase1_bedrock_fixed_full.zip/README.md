# SM+RTE AI Workspace

Run with `pip install -r requirements.txt && streamlit run streamlit_app.py` or build Docker.