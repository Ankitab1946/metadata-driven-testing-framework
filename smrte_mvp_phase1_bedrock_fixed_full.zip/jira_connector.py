import os, requests

JIRA_URL = os.getenv("JIRA_URL")
JIRA_USER = os.getenv("JIRA_USER")
JIRA_TOKEN = os.getenv("JIRA_API_TOKEN")
PROJECT_KEY = os.getenv("JIRA_PROJECT_KEY")

def create_jira_story(title, description):
    url = f"{JIRA_URL}/rest/api/3/issue"
    headers = {"Accept":"application/json","Content-Type":"application/json"}
    payload = {
        "fields": {
            "project": {"key": PROJECT_KEY},
            "summary": title,
            "description": description,
            "issuetype": {"name": "Story"}
        }
    }
    r = requests.post(url, headers=headers, auth=(JIRA_USER,JIRA_TOKEN), json=payload)
    r.raise_for_status()
    return r.json()