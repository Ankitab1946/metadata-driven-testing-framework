import networkx as nx
import matplotlib.pyplot as plt
def plot_dependencies(dependencies):
    G = nx.DiGraph()
    for dep in dependencies:
        G.add_edge(dep[0], dep[1])
    nx.draw(G, with_labels=True, node_color='lightblue', edge_color='gray')
    plt.show()
