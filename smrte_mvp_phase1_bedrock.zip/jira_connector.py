import os
from jira import JIRA
jira_server = os.getenv("JIRA_SERVER")
jira_user = os.getenv("JIRA_USER")
jira_token = os.getenv("JIRA_TOKEN")
jira = JIRA(server=jira_server, basic_auth=(jira_user, jira_token))
def create_story(project_key: str, summary: str, description: str):
    issue_dict = {'project':{'key':project_key},'summary':summary,'description':description,'issuetype':{'name':'Story'}}
    issue = jira.create_issue(fields=issue_dict)
    return issue.key
