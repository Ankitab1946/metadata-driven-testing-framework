# SM + RTE AI Workspace (AWS Bedrock)
1. pip install -r requirements.txt
2. Copy .env.example to .env and fill AWS and JIRA credentials.
3. Run with streamlit run streamlit_app.py.
