import streamlit as st
from claude_ai import generate_stories_json, agile_qabot
from jira_connector import create_story

st.title("SM + RTE AI Workspace (AWS Bedrock)")
st.header("Epic to Stories")
epic = st.text_area("Epic Description")
num = st.number_input("Number of Stories", 1, 20, 5)
project_key = st.text_input("Jira Project Key")

if st.button("Generate Stories and Push to Jira"):
    stories = generate_stories_json(epic, num)
    st.json(stories)
    if isinstance(stories, list):
        for s in stories:
            key = create_story(project_key, s.get('title'), s.get('description'))
            st.success(f"Created Story {key}")

st.header("Agile/SAFe Q&A Bot")
q = st.text_input("Ask a question")
if st.button("Get Answer"):
    ans = agile_qabot(q)
    st.write(ans)
