import os, json, boto3

aws_access_key_id = os.getenv("AWS_ACCESS_KEY_ID")
aws_secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY")
aws_session_token = os.getenv("AWS_SESSION_TOKEN")
aws_region = os.getenv("AWS_REGION", "us-east-1")

if aws_session_token:
    bedrock = boto3.client("bedrock-runtime",region_name=aws_region,
        aws_access_key_id=aws_access_key_id,aws_secret_access_key=aws_secret_access_key,aws_session_token=aws_session_token)
else:
    bedrock = boto3.client("bedrock-runtime",region_name=aws_region,
        aws_access_key_id=aws_access_key_id,aws_secret_access_key=aws_secret_access_key)

MODEL_ID = "anthropic.claude-3-5-sonnet-20240620-v1:0"

def generate_stories_json(epic_description: str, num_stories: int = 5):
    prompt = f"""Break down this Epic into {num_stories} user stories. Respond ONLY in JSON array format like:
    [{{"title":"...","description":"...","acceptance_criteria":"..."}}]
    Epic: {epic_description}"""
    body = json.dumps({"messages":[{"role":"user","content":prompt}],"max_tokens":2000})
    response = bedrock.invoke_model(modelId=MODEL_ID, body=body)
    resp_body = json.loads(response['body'].read())
    text = resp_body['content'][0]['text']
    try:
        return json.loads(text)
    except Exception as e:
        return {"error":str(e),"raw":text}

def agile_qabot(question: str):
    prompt = f"You are an Agile/SAFe expert. Answer clearly:\n\n{question}"
    body = json.dumps({"messages":[{"role":"user","content":prompt}],"max_tokens":800})
    response = bedrock.invoke_model(modelId=MODEL_ID, body=body)
    resp_body = json.loads(response['body'].read())
    return resp_body['content'][0]['text']
