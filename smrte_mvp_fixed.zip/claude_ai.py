# Auto-patched on 2025-09-17T01:00:45.313656Z
import os
import json
import boto3
from botocore.exceptions import ClientError

# Read model and region from environment; provide safe defaults
BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.titan-text-premier-v1:0")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")

# Create a Bedrock Runtime client
_bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION)

def _raise_access_denied(model_id: str, region: str):
    raise RuntimeError(
        f"Bedrock access denied for model '{model_id}' in region '{region}'. "
        "Fix by: (1) choosing a permitted model ID, (2) matching a supported region, "
        "or (3) updating IAM to allow bedrock:InvokeModel for the model ARN."
    )

def invoke_bedrock(messages, max_tokens: int = 1024, temperature: float = 0.4, top_p: float = 0.9):
    """Generic Bedrock text generation wrapper.

    This default implementation targets **Amazon Titan Text** family.
    If you switch to Anthropic on Bedrock, use `invoke_bedrock_anthropic` below.
    `messages` is a list of dicts like: [{"role":"user","content":"..."}, ...]
    """
    if not isinstance(messages, list):
        messages = [{"role":"user","content": str(messages)}]

    prompt = "\n".join([m.get("content","") for m in messages])

    body = {
        "inputText": prompt,
        "textGenerationConfig": {
            "maxTokenCount": int(max_tokens),
            "temperature": float(temperature),
            "topP": float(top_p)
        }
    }

    try:
        resp = _bedrock.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            accept="application/json",
            contentType="application/json",
            body=json.dumps(body)
        )
        payload = json.loads(resp["body"].read())
        return payload.get("outputText","").strip()
    except ClientError as e:
        code = e.response.get("Error",{}).get("Code","")
        msg = e.response.get("Error",{}).get("Message","")
        if "AccessDenied" in code or "AccessDeniedException" in code or "access denied" in msg.lower():
            _raise_access_denied(BEDROCK_MODEL_ID, AWS_REGION)
        raise

def invoke_bedrock_anthropic(messages, max_tokens: int = 1024, temperature: float = 0.4, top_p: float = 0.9):
    """Bedrock Anthropic (Claude 3.x/3.5) wrapper.

    Requires BEDROCK_MODEL_ID to be an Anthropic model id such as:
    - anthropic.claude-3-sonnet-20240229-v1:0
    - anthropic.claude-3-5-sonnet-20240620-v1:0

    `messages` follows the Anthropic format: [{"role":"user","content":"..."}, ...]
    """
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": int(max_tokens),
        "temperature": float(temperature),
        "top_p": float(top_p),
        "messages": messages,
    }

    try:
        resp = _bedrock.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            accept="application/json",
            contentType="application/json",
            body=json.dumps(body)
        )
        payload = json.loads(resp["body"].read())
        # Claude responses have a list of content blocks
        text = "".join([blk.get("text","") for blk in payload.get("content", [])])
        return text.strip()
    except ClientError as e:
        code = e.response.get("Error",{}).get("Code","")
        msg = e.response.get("Error",{}).get("Message","")
        if "AccessDenied" in code or "AccessDeniedException" in code or "access denied" in msg.lower():
            _raise_access_denied(BEDROCK_MODEL_ID, AWS_REGION)
        raise
