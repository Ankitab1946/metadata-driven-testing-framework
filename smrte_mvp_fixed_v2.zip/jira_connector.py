import os
import requests
from requests.auth import HTTPBasicAuth
import json

jira_server = os.getenv("JIRA_SERVER").rstrip('/')
jira_user = os.getenv("JIRA_USER")
jira_token = os.getenv("JIRA_TOKEN")
EPIC_LINK_FIELD = os.getenv("JIRA_EPIC_LINK_FIELD", "customfield_10014")

auth = HTTPBasicAuth(jira_user, jira_token)
headers = {"Accept": "application/json", "Content-Type": "application/json"}

def create_story(project_key: str, summary: str, description: str, epic_key: str = None):
    url = f"{jira_server}/rest/api/3/issue"
    payload = {
        "fields": {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": "Story"}
        }
    }
    if epic_key:
        payload['fields'][EPIC_LINK_FIELD] = epic_key
    response = requests.post(url, json=payload, headers=headers, auth=auth)
    if response.status_code in (200, 201):
        return response.json().get('key')
    else:
        # try to include useful info for debugging
        try:
            j = response.json()
        except Exception:
            j = response.text
        raise Exception(f"Failed to create Jira issue: {response.status_code} {j}")

def search_issues(jql: str, max_results: int = 100):
    url = f"{jira_server}/rest/api/3/search"
    params = {"jql": jql, "maxResults": max_results}
    response = requests.get(url, headers=headers, auth=auth, params=params)
    if response.status_code == 200:
        return response.json().get('issues', [])
    else:
        try:
            j = response.json()
        except Exception:
            j = response.text
        raise Exception(f"Failed to search Jira: {response.status_code} {j}")
