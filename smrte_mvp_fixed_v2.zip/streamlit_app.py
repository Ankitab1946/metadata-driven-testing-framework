import os
import streamlit as st
from dotenv import load_dotenv
import streamlit as st
def bedrock_healthcheck():
    try:
        _ = invoke_bedrock([{"role":"user","content":"OK?"}], max_tokens=5)
        st.sidebar.success("Bedrock model access OK.")
    except Exception as e:
        st.sidebar.error(f"Bedrock access issue: {e}")

load_dotenv()

from claude_ai import generate_stories_json, agile_qabot
from jira_connector import create_story, search_issues
from dependency_graph import plot_dependency_graph_from_issues

st.set_page_config(page_title="SM + RTE AI Assistant", layout="wide")

st.title("🤝 SM + RTE AI Ecosystem – Phase-1 (Preview before Create)")

tab1, tab2, tab3 = st.tabs(["Epic → Stories (Preview)", "Dependency Graph", "Agile Q&A"])

with tab1:
    st.header("Generate user stories from an Epic / Feature (preview before creating in Jira)")
    project = st.text_input("Jira Project Key (e.g. PROJ)", key="proj_input")
    epic_key = st.text_input("Epic Key (optional, e.g. PROJ-123)", key="epic_input")
    epic_text = st.text_area("Enter Epic / Feature description", height=200)
    num = st.slider("Number of stories to generate", 1, 12, 5)

    if st.button("Generate Stories", key="gen_btn"):
        if not epic_text.strip():
            st.error("Please enter an epic/feature description.")
        else:
            with st.spinner("Generating stories from model..."):
                result = generate_stories_json(epic_text, num)
            if isinstance(result, dict) and result.get('error'):
                st.error("Model response could not be parsed as JSON. See raw output below for debugging.")
                st.code(result.get('raw', ''))
            elif isinstance(result, list):
                st.session_state['generated_stories'] = result
            else:
                st.error("Unexpected response from model.")

    if 'generated_stories' in st.session_state:
        st.markdown("### Preview generated stories (select which to create in Jira)")
        gs = st.session_state['generated_stories']
        # render each story with a checkbox
        for i, s in enumerate(gs):
            title = s.get('title') or s.get('name') or f"Story {i+1}"
            desc = s.get('description') or s.get('desc') or ''
            ac = s.get('acceptance_criteria') or s.get('acceptanceCriteria') or ''
            checkbox_key = f"create_{i}"
            checked = st.checkbox(f"{i+1}. {title}", key=checkbox_key)
            st.write(desc)
            if ac:
                st.info(f"**Acceptance Criteria:**\n{ac}")


        if st.button("Create Selected Stories in Jira", key="create_btn"):
            if not project.strip():
                st.error("Please enter the Jira Project Key before creating stories.")
            else:
                created = []
                errors = []
                gs_local = st.session_state.get('generated_stories', [])
                for i, s in enumerate(gs_local):
                    checkbox_key = f"create_{i}"
                    if st.session_state.get(checkbox_key):
                        title = s.get('title') or s.get('name') or f"Story {i+1}"
                        desc = s.get('description') or s.get('desc') or ''
                        ac = s.get('acceptance_criteria') or s.get('acceptanceCriteria') or ''
                        full_description = desc + "\n\nAcceptance Criteria:\n" + ac if ac else desc
                        try:
                            issue_key = create_story(project, title, full_description, epic_key or None)
                            created.append(issue_key)
                        except Exception as e:
                            errors.append(str(e))
                if created:
                    st.success(f"Created stories in Jira: {', '.join(created)}")
                if errors:
                    st.error('Some errors occurred while creating stories:')
                    for e in errors:
                        st.write(e)

with tab2:
    st.header("Visualize dependencies from Jira (uses issuelinks)")
    proj_for_deps = st.text_input("Enter Jira Project Key to fetch issues for dependency graph", key='dep_proj')
    if st.button("Fetch and Visualize", key='fetch_deps'):
        if not proj_for_deps.strip():
            st.error("Enter a project key to fetch issues.")
        else:
            jql = f"project = {proj_for_deps} AND issuetype in (Story,Task,\"Technical Task\") ORDER BY created DESC"
            try:
                issues = search_issues(jql, max_results=200)
                st.write(f"Fetched {len(issues)} issues. Building graph...")
                plot_dependency_graph_from_issues(issues)
            except Exception as e:
                st.error(f"Failed to fetch issues: {e}")

with tab3:
    st.header("Agile Knowledge Hub (Q&A)")
    question = st.text_input("Ask a SAFe/Agile question:", key='qa_input')
    if st.button("Get Answer", key='qa_btn'):
        if not question.strip():
            st.error("Write a question first.")
        else:
            with st.spinner("Fetching answer..."):
                ans = agile_qabot(question)
            st.markdown("**Answer:**")
            st.write(ans)
