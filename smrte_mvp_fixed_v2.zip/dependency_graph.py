import networkx as nx
import matplotlib.pyplot as plt
import streamlit as st

def plot_dependency_graph_from_issues(issues):
    # Build directed graph using issuelinks if available
    G = nx.DiGraph()
    for issue in issues:
        key = issue.get('key')
        summary = issue.get('fields', {}).get('summary', '')
        G.add_node(key, label=summary)
    # extract edges from issuelinks
    for issue in issues:
        key = issue.get('key')
        links = issue.get('fields', {}).get('issuelinks', []) or []
        for link in links:
            # outwardIssue means current -> outward
            if 'outwardIssue' in link:
                target = link['outwardIssue'].get('key')
                if target:
                    G.add_edge(key, target)
            # inwardIssue means inward -> current
            if 'inwardIssue' in link:
                source = link['inwardIssue'].get('key')
                if source:
                    G.add_edge(source, key)

    if len(G.nodes) == 0:
        st.info('No issues to display')
        return

    fig, ax = plt.subplots(figsize=(10, 6))
    pos = nx.spring_layout(G, k=0.6, iterations=50)
    nx.draw_networkx_nodes(G, pos, node_size=800, ax=ax)
    nx.draw_networkx_labels(G, pos, font_size=8, ax=ax)
    nx.draw_networkx_edges(G, pos, arrowstyle='-|>', arrowsize=12, ax=ax)
    st.pyplot(fig)
