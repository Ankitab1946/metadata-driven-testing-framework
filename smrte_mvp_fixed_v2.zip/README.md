# SM + RTE AI Workspace — Phase-1 (Preview before Create)

## What this contains
- Streamlit app that generates user stories from an Epic using an LLM via AWS Bedrock.
- Allows previewing generated stories and selecting which ones to create in Jira.
- Dependency visualization using Jira issuelinks.
- Agile Q&A powered by the model.

## Setup
1. Copy `.env.example` to `.env` and fill in your AWS and Jira credentials.
2. (Optional) update `BEDROCK_MODEL_ID` in `.env` if you want a different model.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run locally:
   ```bash
   streamlit run streamlit_app.py
   ```

## Docker
   ```bash
   docker build -t smrte-mvp .
   docker run -p 8501:8501 --env-file .env smrte-mvp
   ```

## Notes
- Verify `JIRA_EPIC_LINK_FIELD` if you want the created stories linked to an Epic. Jira Cloud commonly uses `customfield_10014`, but your instance may differ.
- Bedrock/API responses can vary; the app attempts to parse JSON arrays from the model output. If parsing fails, you'll see raw output for debugging.

## Bedrock configuration (patched)

This project now reads Bedrock settings from environment variables:

```
AWS_REGION=us-east-1
BEDROCK_MODEL_ID=amazon.titan-text-premier-v1:0
```

Update `.env` (create from `.env.example`) to a model/region your AWS account is allowed to use.
Make sure your IAM role/user has `bedrock:InvokeModel` (and optionally `bedrock:InvokeModelWithResponseStream`) on the model ARN.

If you prefer Anthropic on Bedrock, set:
```
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20240620-v1:0
```
and switch calls to `invoke_bedrock_anthropic(...)` if your prompts assume the Anthropic message format.
