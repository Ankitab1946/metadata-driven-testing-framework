# Auto-patched on 2025-09-17T01:00:45.313656Z
import os
import json
import boto3
from botocore.exceptions import ClientError

# Read model and region from environment; provide safe defaults
BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.titan-text-premier-v1:0")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")

# Create a Bedrock Runtime client
_bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION)

def _raise_access_denied(model_id: str, region: str):
    raise RuntimeError(
        f"Bedrock access denied for model '{model_id}' in region '{region}'. "
        "Fix by: (1) choosing a permitted model ID, (2) matching a supported region, "
        "or (3) updating IAM to allow bedrock:InvokeModel for the model ARN."
    )

def invoke_bedrock(messages, max_tokens: int = 1024, temperature: float = 0.4, top_p: float = 0.9):
    """Generic Bedrock text generation wrapper.

    This default implementation targets **Amazon Titan Text** family.
    If you switch to Anthropic on Bedrock, use `invoke_bedrock_anthropic` below.
    `messages` is a list of dicts like: [{"role":"user","content":"..."}, ...]
    """
    if not isinstance(messages, list):
        messages = [{"role":"user","content": str(messages)}]

    prompt = "\n".join([m.get("content","") for m in messages])

    body = {
        "inputText": prompt,
        "textGenerationConfig": {
            "maxTokenCount": int(max_tokens),
            "temperature": float(temperature),
            "topP": float(top_p)
        }
    }

    try:
        resp = _bedrock.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            accept="application/json",
            contentType="application/json",
            body=json.dumps(body)
        )
        payload = json.loads(resp["body"].read())
        return payload.get("outputText","").strip()
    except ClientError as e:
        code = e.response.get("Error",{}).get("Code","")
        msg = e.response.get("Error",{}).get("Message","")
        if "AccessDenied" in code or "AccessDeniedException" in code or "access denied" in msg.lower():
            _raise_access_denied(BEDROCK_MODEL_ID, AWS_REGION)
        raise

def invoke_bedrock_anthropic(messages, max_tokens: int = 1024, temperature: float = 0.4, top_p: float = 0.9):
    """Bedrock Anthropic (Claude 3.x/3.5) wrapper.

    Requires BEDROCK_MODEL_ID to be an Anthropic model id such as:
    - anthropic.claude-3-sonnet-20240229-v1:0
    - anthropic.claude-3-5-sonnet-20240620-v1:0

    `messages` follows the Anthropic format: [{"role":"user","content":"..."}, ...]
    """
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": int(max_tokens),
        "temperature": float(temperature),
        "top_p": float(top_p),
        "messages": messages,
    }

    try:
        resp = _bedrock.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            accept="application/json",
            contentType="application/json",
            body=json.dumps(body)
        )
        payload = json.loads(resp["body"].read())
        # Claude responses have a list of content blocks
        text = "".join([blk.get("text","") for blk in payload.get("content", [])])
        return text.strip()
    except ClientError as e:
        code = e.response.get("Error",{}).get("Code","")
        msg = e.response.get("Error",{}).get("Message","")
        if "AccessDenied" in code or "AccessDeniedException" in code or "access denied" in msg.lower():
            _raise_access_denied(BEDROCK_MODEL_ID, AWS_REGION)
        raise


# ---------------- Convenience helpers for app modules ----------------

def _coerce_model_json(text: str):
    """Try to coerce model output into JSON, even if it includes Markdown fences."""
    if not text:
        return None
    # Try direct JSON
    try:
        return json.loads(text)
    except Exception:
        pass
    # Extract fenced JSON
    m = re.search(r"```(?:json)?\s*(\{[\s\S]*?\}|\[[\s\S]*?\])\s*```", text, re.IGNORECASE)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    # Try to find first {...} or [...] block
    m2 = re.search(r"(\{[\s\S]*\}|\[[\s\S]*\])", text)
    if m2:
        try:
            return json.loads(m2.group(1))
        except Exception:
            pass
    return None

def generate_stories_json(feature_text: str, story_count: int = 6):
    """Turn a high-level feature description into a JSON list of user stories.
    Output schema:
    [
      {
        "title": str,
        "as_a": str,
        "i_want": str,
        "so_that": str,
        "description": str,
        "acceptance_criteria": [str, ...],
        "estimate_points": int
      },
      ...
    ]
    """
    system = {"role":"user","content": f"""You are an Agile BA. Create {story_count} INVEST-quality user stories from the feature.
Return JSON only in the schema shown. Keep titles concise; estimates 1-8.
Feature:\n{feature_text}"""}
    raw = invoke_bedrock([system], max_tokens=1800, temperature=0.3, top_p=0.9)
    data = _coerce_model_json(raw)
    if not isinstance(data, list):
        # Fallback minimal story if the model didn't return valid JSON
        data = [{
            "title": "Draft story from feature",
            "as_a": "user",
            "i_want": "capability derived from feature",
            "so_that": "business value",
            "description": feature_text[:500],
            "acceptance_criteria": [
                "GIVEN a valid scenario WHEN the user performs an action THEN the expected outcome occurs"
            ],
            "estimate_points": 3
        }]
    return data

def generate_dependency_graph_json(issues_text: str):
    """Create a simple dependency graph from pasted Jira issue list or text.
    Output schema:
    {
      "nodes": [{"id": "KEY-1", "label": "Title"}, ...],
      "edges": [{"source": "KEY-1", "target": "KEY-2", "type": "blocks"}, ...]
    }
    """
    prompt = {"role":"user","content": f"""From the following text, extract Jira-like items and dependencies (blocks/is blocked by/depends on).
Return JSON only with nodes(id,label) and edges(source,target,type in {{blocks, relates, duplicates}}).
Text:\n{issues_text}"""}
    raw = invoke_bedrock([prompt], max_tokens=1400, temperature=0.2, top_p=0.9)
    data = _coerce_model_json(raw)
    if not isinstance(data, dict) or "nodes" not in data:
        data = {"nodes": [], "edges": []}
    return data

def answer_agile_question(question: str, context: str = None):
    """Answer agile questions with short, practical guidance."""
    base = "You are a seasoned Agile coach. Answer concisely with practical steps. If the answer depends on context, state assumptions."
    content = base + (f"\nContext:\n{context}" if context else "") + f"\nQuestion:\n{question}"
    msg = {"role":"user","content": content}
    return invoke_bedrock([msg], max_tokens=800, temperature=0.2, top_p=0.9)

__all__ = ['invoke_bedrock', 'invoke_bedrock_anthropic', 'generate_stories_json', 'generate_dependency_graph_json', 'answer_agile_question']
