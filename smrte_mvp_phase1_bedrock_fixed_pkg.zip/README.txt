This is a placeholder README for smrte_mvp_phase1_bedrock_fixed package.
