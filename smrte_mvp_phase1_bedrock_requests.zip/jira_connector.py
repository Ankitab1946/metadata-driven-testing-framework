import os
import requests
from requests.auth import HTTPBasicAuth

jira_server = os.getenv("JIRA_SERVER")
jira_user = os.getenv("JIRA_USER")
jira_token = os.getenv("JIRA_TOKEN")

auth = HTTPBasicAuth(jira_user, jira_token)
headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"
}

def create_story(project_key: str, summary: str, description: str):
    url = f"{jira_server}/rest/api/3/issue"
    payload = {
        "fields": {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": "Story"}
        }
    }
    response = requests.post(url, json=payload, headers=headers, auth=auth)
    if response.status_code == 201:
        data = response.json()
        return data.get("key")
    else:
        raise Exception(f"Jira issue creation failed: {response.status_code} {response.text}")

def search_issues(jql: str, max_results: int = 50):
    url = f"{jira_server}/rest/api/3/search"
    params = {"jql": jql, "maxResults": max_results}
    response = requests.get(url, headers=headers, auth=auth, params=params)
    if response.status_code == 200:
        return response.json()["issues"]
    else:
        raise Exception(f"Jira search failed: {response.status_code} {response.text}")
