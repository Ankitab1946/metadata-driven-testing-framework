import streamlit as st
from claude_ai import generate_stories
from jira_connector import create_story

st.title("SM+RTE AI - Epic to Stories")

epic = st.text_area("Enter Epic/Feature text")
project = st.text_input("Jira Project Key")

if st.button("Generate Stories"):
    with st.spinner("Generating..."):
        result = generate_stories(epic)
        st.text_area("Generated Stories", result, height=300)
        if st.button("Create Stories in Jira"):
            for line in result.splitlines():
                if line.strip():
                    story_key = create_story(project, line[:100], line)
                    st.success(f"Created story {story_key}")
