# SM+RTE AI MVP (AWS Bedrock + Jira REST API)

## Setup
1. `pip install -r requirements.txt`
2. Copy `.env.example` to `.env` and set AWS & Jira credentials.
3. Run: `streamlit run streamlit_app.py`

## Docker
`docker build -t smrte-mvp .`  
`docker run -p 8501:8501 --env-file .env smrte-mvp`
